import { useEffect, useRef } from 'react'
import Lenis from 'lenis'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Aurora from './rb/Aurora'
import SplitText from './rb/SplitText'
import ShinyText from './rb/ShinyText'
import CountUp from './rb/CountUp'
import TiltedCard from './rb/TiltedCard'
import SpotlightCard from './rb/SpotlightCard'
gsap.registerPlugin(ScrollTrigger)
const items = ['rocket', 'video_game', 'fire', 'sparkles', 'crossed_swords', 'shopping_cart']
export default function App() {
  const track = useRef<HTMLDivElement>(null), pin = useRef<HTMLDivElement>(null)
  useEffect(() => {
    // 不要做原则 §7：系统开启“减少动效”时不初始化 Lenis，也不做滚动动画，页面按原生滚动
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) { document.documentElement.dataset.reducedMotion = '1'; return }
    // 只做惯性平滑，不改滚动方向、不分页；键盘/触摸保持原生
    const lenis = new Lenis({ smoothWheel: true, syncTouch: false }); (window as any).lenis = lenis
    lenis.on('scroll', ScrollTrigger.update)
    const tick = (t: number) => lenis.raf(t * 1000); gsap.ticker.add(tick); gsap.ticker.lagSmoothing(0)
    const tw = gsap.to(track.current, { x: () => -(track.current!.scrollWidth - innerWidth + 80), ease: 'none',
      scrollTrigger: { trigger: pin.current, pin: true, scrub: 1, end: () => '+=' + track.current!.scrollWidth } })
    gsap.utils.toArray<HTMLElement>('.fade').forEach(el => gsap.from(el, { y: 80, opacity: 0, duration: 1, scrollTrigger: { trigger: el, start: 'top 85%' } }))
    return () => { tw.kill(); gsap.ticker.remove(tick); lenis.destroy() }
  }, [])
  return (<main>
    <section className="relative h-screen flex flex-col items-center justify-center overflow-hidden">
      <div className="absolute inset-0"><Aurora colorStops={['#5227FF', '#7cff67', '#ff6bd5']} amplitude={1.1} blend={0.6} /></div>
      <SplitText text="GitHub 也是素材库" tag="h1" className="smiley relative text-7xl md:text-8xl text-white" splitType="chars" delay={60} />
      <div className="relative mt-6 text-2xl"><ShinyText text="Lenis 平滑滚动 · GSAP 滚动动画 · React Bits 组件" speed={2.5} /></div>
      <p className="relative mt-10 opacity-60">↓ 往下滚</p>
    </section>
    <section className="max-w-5xl mx-auto py-28 grid grid-cols-3 gap-6 text-center">
      {[[110, 'React Bits 组件'], [76, 'KayKit 角色动画'], [4000, 'game-icons 图标']].map(([n, l]) => (
        <div key={l} className="fade"><div className="smiley text-6xl text-[#ffd166]"><CountUp to={n as number} separator="," duration={2} /></div><div className="mt-2 opacity-70">{l}</div></div>))}
    </section>
    <section ref={pin} className="h-screen flex flex-col justify-center overflow-hidden">
      <h2 className="smiley text-5xl px-10 mb-8">GSAP ScrollTrigger 横向滚动 + TiltedCard</h2>
      <div ref={track} className="flex gap-10 px-10 w-max">
        {items.map(i => <div key={i} className="w-[340px] h-[340px] rounded-3xl bg-[#141a33] flex items-center justify-center">
          <TiltedCard imageSrc={`/a/${i}_3d.png`} altText={i} captionText={i} containerHeight="280px" containerWidth="280px" imageHeight="240px" imageWidth="240px" showMobileWarning={false} />
        </div>)}
      </div>
    </section>
    <section className="max-w-5xl mx-auto py-28 grid grid-cols-3 gap-6">
      {['游戏官网', '独立站落地页', '视频片头'].map(t => <div key={t} className="fade"><SpotlightCard className="p-8 h-48"><h3 className="smiley text-3xl">{t}</h3><p className="mt-3 opacity-70">同一套动效直接复用</p></SpotlightCard></div>)}
    </section>
    <footer className="h-[40vh] flex items-center justify-center smiley text-4xl opacity-60">END</footer>
  </main>)
}
